import { useState } from 'react'

import './App.css'
import './popup'
import Popup from './popup';
import Sample from './table'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Container} from 'react-bootstrap';

function App() {

  // const [count, setCount] = useState(0);
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  

  return (
    <>
    <Container fluid className='p-4'>
      <Popup popShow={show} popClose={handleClose}/>
      <Sample boxClick={handleShow}/>
      </Container>
    </>
  )
}

export default App;
