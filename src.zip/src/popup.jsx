// import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';

function Popup(popParameter) {

// const [show, setShow] = useState(false);
//   const handleClose = () => setShow(false);
//   const handleShow = () => setShow(true);

    return(

        <>
      {/* <Button variant="primary m-3" onClick={handleShow} >
        Launch demo modal
      </Button> */}

      <Modal show={popParameter.popShow} onHide={popParameter.popClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Contents</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>User Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="User name"
                autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="name@example.com"
                autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Phone no</Form.Label>
              <Form.Control
                type="text"
                placeholder="+91-000-000-0000"
                autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Location</Form.Label>
              <Form.Control
                type="text"
                placeholder="Name of the place"
                autoFocus
              />
            </Form.Group>
            

          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={popParameter.popClose}>
            Close
          </Button>
          <Button variant="primary" onClick={popParameter.popClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>

    )
}

export default Popup;